var ct = require('./check_types');

console.log(ct.check(['chat', [0, 0], 5]));


