var http = require('http');

exports.start = function(port) {
	
	http.createServer(function (req, res) {
		//res.writeHead(200, {'Content-Type': 'text/plain'});
		//res.end('Hello World\n');

		res.writeHead(200, {"Content-Type": "text/html"});
		res.write('<!DOCTYPE html>'+
			'<html>'+
			'    <head>'+
			'        <meta charset="utf-8" />'+
			'        <title>Welcome !</title>'+
			'    </head>'+ 
			'    <body>'+
			'     	<p>Greetings <strong>Traveller</strong> !</p>'+
			'    </body>'+
			'</html>');
		res.end();

	}).listen(port);

}


