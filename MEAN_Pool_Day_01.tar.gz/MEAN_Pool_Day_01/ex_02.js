var fs = require('fs');
var dir = __dirname + '/garbage';
console.log(dir);

var numberOfFiles = process.argv[2];

if (isNaN(numberOfFiles)) {
	console.log("Error");

} else {
	if (!fs.existsSync(dir)) {
		fs.mkdirSync(dir);
	} else {
		var files = fs.readdirSync(dir);
		console.log(files);
		if (files.length > 0)
			for (var i = 0; i < files.length; i++) {
				var filePath = dir + '/' + files[i];
				if (fs.statSync(filePath).isFile())
					fs.unlinkSync(filePath);
			}
		}

	if (fs.existsSync(dir)) {
			for ( var i = 0; i < numberOfFiles; i++ ) {
				var fileNumber = i + 1;
				fs.openSync(dir + '/'+ fileNumber + '.js', 'w');
				console.log('created file '+ fileNumber + '.js');
		}
	}

}
