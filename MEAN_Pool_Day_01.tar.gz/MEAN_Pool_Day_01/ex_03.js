var fs = require('fs');
var dir = __dirname;

var masterFile = process.argv[2];
var copyFile = process.argv[3];

if (!fs.existsSync(dir + '/' + masterFile)) {

} else {

	fs.readFile( dir + '/' + masterFile, 'utf8', function(err, data){
		fs.writeFile( dir + '/' + copyFile, data, function(){});
	})

}