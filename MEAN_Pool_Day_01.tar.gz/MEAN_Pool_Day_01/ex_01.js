var arguments = process.argv;
//console.log(arguments);
for (var i = 2; i < arguments.length; i++) {
	if( !isNaN(arguments[i]))
		console.log(arguments[i]);
}