var server = require('./server');

server.start(8080);
