var server = require('./server1');

server.start(8080);