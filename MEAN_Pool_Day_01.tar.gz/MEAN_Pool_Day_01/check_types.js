var Type = require('type-of-is');

var typeOf = function(element) {
	console.log(Type.string(element));
  	return Type.string(element); 
}

function map(array, transform) {
  var mapped = [];
  for (var i = 0; i < array.length; i++) {

  	console.log(transform(array[i]));
    mapped.push(transform(array[i]));
	console.log(mapped[i]);
}

  return mapped;
}

exports.check = function(array) {
	console.log(array);
	var arrayType = map(array, typeOf);
	return arrayType;
}