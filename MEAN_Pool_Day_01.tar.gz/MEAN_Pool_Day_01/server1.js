var http = require('http');
var fs = require('fs');
var url = require('url'); 
var querystring = require('querystring');

exports.start = function(port) {

	fs.readFile('./index.html', function (err, html) {
		if (err) {
			throw err; 
		}       
		http.createServer(function(request, response) {
			var params = querystring.parse(url.parse(request.url).query);
			console.log("LOL")
			console.log(params.name);
			console.log("pol")
			response.writeHeader(200, {"Content-Type": "text/html"});
			if ('name' in params) {
				response.write(html.toString().replace(/Traveller/g, params.name));
			} else {
				response.write(html); 
			}

			 
			response.end();  
		}).listen(port);
	});



	
	/*http.createServer(function (req, res) {
		//res.writeHead(200, {'Content-Type': 'text/plain'});
		//res.end('Hello World\n');

		res.writeHead(200, {"Content-Type": "text/html"});
		res.read('<!DOCTYPE html>'+
			'<html>'+
			'    <head>'+
			'        <meta charset="utf-8" />'+
			'        <title>Welcome !</title>'+
			'    </head>'+ 
			'    <body>'+
			'     	<p>Greetings <strong>Traveller</strong> !</p>'+
			'    </body>'+
			'</html>');
		res.end();

	}).listen(port);*/

}


